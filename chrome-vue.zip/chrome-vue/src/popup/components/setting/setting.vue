<template>
    <div class="home">
        输入框的值
        {{ value }}
    </div>
</template>

<script>
    import { mapState } from 'vuex'
    export default {
        data() {
            return {
                value: ''
            }
        },
        computed: {
            ...mapState(['base'])
        },
        mounted () {
            this.$set(this, 'value', this.base.userId)
            alert(JSON.stringify(this.base))
        }
    }
</script>

<style scoped>

</style>