<template>
    <div class="home">
        <input type="text" v-model="value" @input="valChange">
    </div>
</template>

<script>
    import { mapActions, mapState } from 'vuex'
    export default {
        data() {
            return {
                value: ''
            }
        },
        computed: {
            ...mapState(['base'])
        },
        methods: {
            ...mapActions(['ACT_USERID']),
            valChange () {
                this.ACT_USERID(this.value)
            }
        },
        mounted () {
            this.$set(this, 'value', this.base.userId)
        }
    }
</script>

<style scoped>

</style>