<template>
    <!-- <el-card class="box-card">
      <div v-for="o in list" :key="o.path" class="text item" @click="goRouter(o)">{{ o.title }}</div>
    </el-card> -->
  <div class="box-card">
    <router-link to="/">首页</router-link>
    <router-link to="/setting">设置</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "app",
  data() {
    return {
      list: [{
        title: '首页',
        path: '/'
      }, {
        title: '设置',
        path: '/setting'
      }]
    }
  },
  methods: {
    goRouter (e) {
      console.log(e)
      this.$router.push({
        path: e.path
      })
    }
  }
};
</script>

<style>
  #app {
    height: 100px;
  }
  .box {
    height: 300px;
  }
  .box-card {
    font-size: 16px;
    width: 100px;
    height: 100px;
  }
  .box-card div {
    width: 100px;
    height: 40px;
  }
</style>
