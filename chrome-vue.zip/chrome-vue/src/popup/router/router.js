import Vue from 'vue'
import vueRouter from 'vue-router'
Vue.use(vueRouter)

import Home from '../components/home/home'
import Setting from '../components/setting/setting'
const baseRouter = [
    {
        path: '/',
        name: 'home',
        component: Home
    },
    {
        path: '/setting',
        name: 'setting',
        component: Setting
    }
]

const router = new vueRouter({
    routes: baseRouter
})


export {
    router
}