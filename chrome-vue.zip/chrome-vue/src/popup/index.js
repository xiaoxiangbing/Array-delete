import Vue from 'vue'
import AppComponent from './App/App.vue'
import { router } from './router/router'
import store from './store'
import { Card } from 'element-ui'

Vue.use(Card)

new Vue({
    el: '#app',
    router,
    store,
    render: createElement => {
        return createElement(AppComponent);
    }    
})
