import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import base from './store/base.js'

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        base
    },
    plugins: [
        createPersistedState({
            key: 'chrome-vue',
            paths: ['base']
        })
    ]
})