export default {
    state: {
        userId: ''
    },
    mutations: {
        MUT_USERID (state, value) {
            state.userId = value
        }
    },
    actions: {
        ACT_USERID (context, value) {
            context.commit('MUT_USERID', value)
        }
    }
}